<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">

			<meta name="viewport" content="width=device-width, initial-scale=1">
	
	
	<meta name='robots' content='noindex, follow' />

	<!-- This site is optimized with the Yoast SEO plugin v26.8 - https://yoast.com/product/yoast-seo-wordpress/ -->
	<title>Página no encontrada - Hostal Sol Zamora</title>
	<meta property="og:locale" content="es_ES" />
	<meta property="og:title" content="Página no encontrada - Hostal Sol Zamora" />
	<meta property="og:site_name" content="Hostal Sol Zamora" />
	<script type="application/ld+json" class="yoast-schema-graph">{"@context":"https://schema.org","@graph":[{"@type":"WebSite","@id":"https://hostalsolzamora.com/#website","url":"https://hostalsolzamora.com/","name":"Hostal Sol Zamora","description":"","potentialAction":[{"@type":"SearchAction","target":{"@type":"EntryPoint","urlTemplate":"https://hostalsolzamora.com/?s={search_term_string}"},"query-input":{"@type":"PropertyValueSpecification","valueRequired":true,"valueName":"search_term_string"}}],"inLanguage":"es"}]}</script>
	<!-- / Yoast SEO plugin. -->


<link rel='dns-prefetch' href='//www.googletagmanager.com' />
<link rel='dns-prefetch' href='//use.fontawesome.com' />
<link rel='dns-prefetch' href='//fonts.googleapis.com' />
<link rel='preconnect' href='https://fonts.gstatic.com' crossorigin />
<link rel="alternate" type="application/rss+xml" title="Hostal Sol Zamora &raquo; Feed" href="https://hostalsolzamora.com/feed" />
<link rel="alternate" type="application/rss+xml" title="Hostal Sol Zamora &raquo; Feed de los comentarios" href="https://hostalsolzamora.com/comments/feed" />
<style id='wp-img-auto-sizes-contain-inline-css' type='text/css'>
img:is([sizes=auto i],[sizes^="auto," i]){contain-intrinsic-size:3000px 1500px}
/*# sourceURL=wp-img-auto-sizes-contain-inline-css */
</style>
<style id='wp-emoji-styles-inline-css' type='text/css'>

	img.wp-smiley, img.emoji {
		display: inline !important;
		border: none !important;
		box-shadow: none !important;
		height: 1em !important;
		width: 1em !important;
		margin: 0 0.07em !important;
		vertical-align: -0.1em !important;
		background: none !important;
		padding: 0 !important;
	}
/*# sourceURL=wp-emoji-styles-inline-css */
</style>
<link rel="stylesheet" href="https://hostalsolzamora.com/wp-content/cache/minify/a5ff7.css" media="all" />


<style id='wp-block-image-inline-css' type='text/css'>
.wp-block-image>a,.wp-block-image>figure>a{display:inline-block}.wp-block-image img{box-sizing:border-box;height:auto;max-width:100%;vertical-align:bottom}@media not (prefers-reduced-motion){.wp-block-image img.hide{visibility:hidden}.wp-block-image img.show{animation:show-content-image .4s}}.wp-block-image[style*=border-radius] img,.wp-block-image[style*=border-radius]>a{border-radius:inherit}.wp-block-image.has-custom-border img{box-sizing:border-box}.wp-block-image.aligncenter{text-align:center}.wp-block-image.alignfull>a,.wp-block-image.alignwide>a{width:100%}.wp-block-image.alignfull img,.wp-block-image.alignwide img{height:auto;width:100%}.wp-block-image .aligncenter,.wp-block-image .alignleft,.wp-block-image .alignright,.wp-block-image.aligncenter,.wp-block-image.alignleft,.wp-block-image.alignright{display:table}.wp-block-image .aligncenter>figcaption,.wp-block-image .alignleft>figcaption,.wp-block-image .alignright>figcaption,.wp-block-image.aligncenter>figcaption,.wp-block-image.alignleft>figcaption,.wp-block-image.alignright>figcaption{caption-side:bottom;display:table-caption}.wp-block-image .alignleft{float:left;margin:.5em 1em .5em 0}.wp-block-image .alignright{float:right;margin:.5em 0 .5em 1em}.wp-block-image .aligncenter{margin-left:auto;margin-right:auto}.wp-block-image :where(figcaption){margin-bottom:1em;margin-top:.5em}.wp-block-image.is-style-circle-mask img{border-radius:9999px}@supports ((-webkit-mask-image:none) or (mask-image:none)) or (-webkit-mask-image:none){.wp-block-image.is-style-circle-mask img{border-radius:0;-webkit-mask-image:url('data:image/svg+xml;utf8,<svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg"><circle cx="50" cy="50" r="50"/></svg>');mask-image:url('data:image/svg+xml;utf8,<svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg"><circle cx="50" cy="50" r="50"/></svg>');mask-mode:alpha;-webkit-mask-position:center;mask-position:center;-webkit-mask-repeat:no-repeat;mask-repeat:no-repeat;-webkit-mask-size:contain;mask-size:contain}}:root :where(.wp-block-image.is-style-rounded img,.wp-block-image .is-style-rounded img){border-radius:9999px}.wp-block-image figure{margin:0}.wp-lightbox-container{display:flex;flex-direction:column;position:relative}.wp-lightbox-container img{cursor:zoom-in}.wp-lightbox-container img:hover+button{opacity:1}.wp-lightbox-container button{align-items:center;backdrop-filter:blur(16px) saturate(180%);background-color:#5a5a5a40;border:none;border-radius:4px;cursor:zoom-in;display:flex;height:20px;justify-content:center;opacity:0;padding:0;position:absolute;right:16px;text-align:center;top:16px;width:20px;z-index:100}@media not (prefers-reduced-motion){.wp-lightbox-container button{transition:opacity .2s ease}}.wp-lightbox-container button:focus-visible{outline:3px auto #5a5a5a40;outline:3px auto -webkit-focus-ring-color;outline-offset:3px}.wp-lightbox-container button:hover{cursor:pointer;opacity:1}.wp-lightbox-container button:focus{opacity:1}.wp-lightbox-container button:focus,.wp-lightbox-container button:hover,.wp-lightbox-container button:not(:hover):not(:active):not(.has-background){background-color:#5a5a5a40;border:none}.wp-lightbox-overlay{box-sizing:border-box;cursor:zoom-out;height:100vh;left:0;overflow:hidden;position:fixed;top:0;visibility:hidden;width:100%;z-index:100000}.wp-lightbox-overlay .close-button{align-items:center;cursor:pointer;display:flex;justify-content:center;min-height:40px;min-width:40px;padding:0;position:absolute;right:calc(env(safe-area-inset-right) + 16px);top:calc(env(safe-area-inset-top) + 16px);z-index:5000000}.wp-lightbox-overlay .close-button:focus,.wp-lightbox-overlay .close-button:hover,.wp-lightbox-overlay .close-button:not(:hover):not(:active):not(.has-background){background:none;border:none}.wp-lightbox-overlay .lightbox-image-container{height:var(--wp--lightbox-container-height);left:50%;overflow:hidden;position:absolute;top:50%;transform:translate(-50%,-50%);transform-origin:top left;width:var(--wp--lightbox-container-width);z-index:9999999999}.wp-lightbox-overlay .wp-block-image{align-items:center;box-sizing:border-box;display:flex;height:100%;justify-content:center;margin:0;position:relative;transform-origin:0 0;width:100%;z-index:3000000}.wp-lightbox-overlay .wp-block-image img{height:var(--wp--lightbox-image-height);min-height:var(--wp--lightbox-image-height);min-width:var(--wp--lightbox-image-width);width:var(--wp--lightbox-image-width)}.wp-lightbox-overlay .wp-block-image figcaption{display:none}.wp-lightbox-overlay button{background:none;border:none}.wp-lightbox-overlay .scrim{background-color:#fff;height:100%;opacity:.9;position:absolute;width:100%;z-index:2000000}.wp-lightbox-overlay.active{visibility:visible}@media not (prefers-reduced-motion){.wp-lightbox-overlay.active{animation:turn-on-visibility .25s both}.wp-lightbox-overlay.active img{animation:turn-on-visibility .35s both}.wp-lightbox-overlay.show-closing-animation:not(.active){animation:turn-off-visibility .35s both}.wp-lightbox-overlay.show-closing-animation:not(.active) img{animation:turn-off-visibility .25s both}.wp-lightbox-overlay.zoom.active{animation:none;opacity:1;visibility:visible}.wp-lightbox-overlay.zoom.active .lightbox-image-container{animation:lightbox-zoom-in .4s}.wp-lightbox-overlay.zoom.active .lightbox-image-container img{animation:none}.wp-lightbox-overlay.zoom.active .scrim{animation:turn-on-visibility .4s forwards}.wp-lightbox-overlay.zoom.show-closing-animation:not(.active){animation:none}.wp-lightbox-overlay.zoom.show-closing-animation:not(.active) .lightbox-image-container{animation:lightbox-zoom-out .4s}.wp-lightbox-overlay.zoom.show-closing-animation:not(.active) .lightbox-image-container img{animation:none}.wp-lightbox-overlay.zoom.show-closing-animation:not(.active) .scrim{animation:turn-off-visibility .4s forwards}}@keyframes show-content-image{0%{visibility:hidden}99%{visibility:hidden}to{visibility:visible}}@keyframes turn-on-visibility{0%{opacity:0}to{opacity:1}}@keyframes turn-off-visibility{0%{opacity:1;visibility:visible}99%{opacity:0;visibility:visible}to{opacity:0;visibility:hidden}}@keyframes lightbox-zoom-in{0%{transform:translate(calc((-100vw + var(--wp--lightbox-scrollbar-width))/2 + var(--wp--lightbox-initial-left-position)),calc(-50vh + var(--wp--lightbox-initial-top-position))) scale(var(--wp--lightbox-scale))}to{transform:translate(-50%,-50%) scale(1)}}@keyframes lightbox-zoom-out{0%{transform:translate(-50%,-50%) scale(1);visibility:visible}99%{visibility:visible}to{transform:translate(calc((-100vw + var(--wp--lightbox-scrollbar-width))/2 + var(--wp--lightbox-initial-left-position)),calc(-50vh + var(--wp--lightbox-initial-top-position))) scale(var(--wp--lightbox-scale));visibility:hidden}}
/*# sourceURL=https://hostalsolzamora.com/wp-includes/blocks/image/style.min.css */
</style>

<style id='classic-theme-styles-inline-css' type='text/css'>
/*! This file is auto-generated */
.wp-block-button__link{color:#fff;background-color:#32373c;border-radius:9999px;box-shadow:none;text-decoration:none;padding:calc(.667em + 2px) calc(1.333em + 2px);font-size:1.125em}.wp-block-file__button{background:#32373c;color:#fff;text-decoration:none}
/*# sourceURL=/wp-includes/css/classic-themes.min.css */
</style>
<style id='font-awesome-svg-styles-default-inline-css' type='text/css'>
.svg-inline--fa {
  display: inline-block;
  height: 1em;
  overflow: visible;
  vertical-align: -.125em;
}
/*# sourceURL=font-awesome-svg-styles-default-inline-css */
</style>
<link rel="stylesheet" href="https://hostalsolzamora.com/wp-content/cache/minify/8fc9c.css" media="all" />

<style id='font-awesome-svg-styles-inline-css' type='text/css'>
   .wp-block-font-awesome-icon svg::before,
   .wp-rich-text-font-awesome-icon svg::before {content: unset;}
/*# sourceURL=font-awesome-svg-styles-inline-css */
</style>
<style id='global-styles-inline-css' type='text/css'>
:root{--wp--preset--aspect-ratio--square: 1;--wp--preset--aspect-ratio--4-3: 4/3;--wp--preset--aspect-ratio--3-4: 3/4;--wp--preset--aspect-ratio--3-2: 3/2;--wp--preset--aspect-ratio--2-3: 2/3;--wp--preset--aspect-ratio--16-9: 16/9;--wp--preset--aspect-ratio--9-16: 9/16;--wp--preset--color--black: #000000;--wp--preset--color--cyan-bluish-gray: #abb8c3;--wp--preset--color--white: #ffffff;--wp--preset--color--pale-pink: #f78da7;--wp--preset--color--vivid-red: #cf2e2e;--wp--preset--color--luminous-vivid-orange: #ff6900;--wp--preset--color--luminous-vivid-amber: #fcb900;--wp--preset--color--light-green-cyan: #7bdcb5;--wp--preset--color--vivid-green-cyan: #00d084;--wp--preset--color--pale-cyan-blue: #8ed1fc;--wp--preset--color--vivid-cyan-blue: #0693e3;--wp--preset--color--vivid-purple: #9b51e0;--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple: linear-gradient(135deg,rgb(6,147,227) 0%,rgb(155,81,224) 100%);--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan: linear-gradient(135deg,rgb(122,220,180) 0%,rgb(0,208,130) 100%);--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange: linear-gradient(135deg,rgb(252,185,0) 0%,rgb(255,105,0) 100%);--wp--preset--gradient--luminous-vivid-orange-to-vivid-red: linear-gradient(135deg,rgb(255,105,0) 0%,rgb(207,46,46) 100%);--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray: linear-gradient(135deg,rgb(238,238,238) 0%,rgb(169,184,195) 100%);--wp--preset--gradient--cool-to-warm-spectrum: linear-gradient(135deg,rgb(74,234,220) 0%,rgb(151,120,209) 20%,rgb(207,42,186) 40%,rgb(238,44,130) 60%,rgb(251,105,98) 80%,rgb(254,248,76) 100%);--wp--preset--gradient--blush-light-purple: linear-gradient(135deg,rgb(255,206,236) 0%,rgb(152,150,240) 100%);--wp--preset--gradient--blush-bordeaux: linear-gradient(135deg,rgb(254,205,165) 0%,rgb(254,45,45) 50%,rgb(107,0,62) 100%);--wp--preset--gradient--luminous-dusk: linear-gradient(135deg,rgb(255,203,112) 0%,rgb(199,81,192) 50%,rgb(65,88,208) 100%);--wp--preset--gradient--pale-ocean: linear-gradient(135deg,rgb(255,245,203) 0%,rgb(182,227,212) 50%,rgb(51,167,181) 100%);--wp--preset--gradient--electric-grass: linear-gradient(135deg,rgb(202,248,128) 0%,rgb(113,206,126) 100%);--wp--preset--gradient--midnight: linear-gradient(135deg,rgb(2,3,129) 0%,rgb(40,116,252) 100%);--wp--preset--font-size--small: 13px;--wp--preset--font-size--medium: 20px;--wp--preset--font-size--large: 36px;--wp--preset--font-size--x-large: 42px;--wp--preset--spacing--20: 0.44rem;--wp--preset--spacing--30: 0.67rem;--wp--preset--spacing--40: 1rem;--wp--preset--spacing--50: 1.5rem;--wp--preset--spacing--60: 2.25rem;--wp--preset--spacing--70: 3.38rem;--wp--preset--spacing--80: 5.06rem;--wp--preset--shadow--natural: 6px 6px 9px rgba(0, 0, 0, 0.2);--wp--preset--shadow--deep: 12px 12px 50px rgba(0, 0, 0, 0.4);--wp--preset--shadow--sharp: 6px 6px 0px rgba(0, 0, 0, 0.2);--wp--preset--shadow--outlined: 6px 6px 0px -3px rgb(255, 255, 255), 6px 6px rgb(0, 0, 0);--wp--preset--shadow--crisp: 6px 6px 0px rgb(0, 0, 0);}:where(.is-layout-flex){gap: 0.5em;}:where(.is-layout-grid){gap: 0.5em;}body .is-layout-flex{display: flex;}.is-layout-flex{flex-wrap: wrap;align-items: center;}.is-layout-flex > :is(*, div){margin: 0;}body .is-layout-grid{display: grid;}.is-layout-grid > :is(*, div){margin: 0;}:where(.wp-block-columns.is-layout-flex){gap: 2em;}:where(.wp-block-columns.is-layout-grid){gap: 2em;}:where(.wp-block-post-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-post-template.is-layout-grid){gap: 1.25em;}.has-black-color{color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-color{color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-color{color: var(--wp--preset--color--white) !important;}.has-pale-pink-color{color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-color{color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-color{color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-color{color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-color{color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-color{color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-color{color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-color{color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-color{color: var(--wp--preset--color--vivid-purple) !important;}.has-black-background-color{background-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-background-color{background-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-background-color{background-color: var(--wp--preset--color--white) !important;}.has-pale-pink-background-color{background-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-background-color{background-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-background-color{background-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-background-color{background-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-background-color{background-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-background-color{background-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-background-color{background-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-background-color{background-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-background-color{background-color: var(--wp--preset--color--vivid-purple) !important;}.has-black-border-color{border-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-border-color{border-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-border-color{border-color: var(--wp--preset--color--white) !important;}.has-pale-pink-border-color{border-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-border-color{border-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-border-color{border-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-border-color{border-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-border-color{border-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-border-color{border-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-border-color{border-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-border-color{border-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-border-color{border-color: var(--wp--preset--color--vivid-purple) !important;}.has-vivid-cyan-blue-to-vivid-purple-gradient-background{background: var(--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple) !important;}.has-light-green-cyan-to-vivid-green-cyan-gradient-background{background: var(--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan) !important;}.has-luminous-vivid-amber-to-luminous-vivid-orange-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange) !important;}.has-luminous-vivid-orange-to-vivid-red-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-orange-to-vivid-red) !important;}.has-very-light-gray-to-cyan-bluish-gray-gradient-background{background: var(--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray) !important;}.has-cool-to-warm-spectrum-gradient-background{background: var(--wp--preset--gradient--cool-to-warm-spectrum) !important;}.has-blush-light-purple-gradient-background{background: var(--wp--preset--gradient--blush-light-purple) !important;}.has-blush-bordeaux-gradient-background{background: var(--wp--preset--gradient--blush-bordeaux) !important;}.has-luminous-dusk-gradient-background{background: var(--wp--preset--gradient--luminous-dusk) !important;}.has-pale-ocean-gradient-background{background: var(--wp--preset--gradient--pale-ocean) !important;}.has-electric-grass-gradient-background{background: var(--wp--preset--gradient--electric-grass) !important;}.has-midnight-gradient-background{background: var(--wp--preset--gradient--midnight) !important;}.has-small-font-size{font-size: var(--wp--preset--font-size--small) !important;}.has-medium-font-size{font-size: var(--wp--preset--font-size--medium) !important;}.has-large-font-size{font-size: var(--wp--preset--font-size--large) !important;}.has-x-large-font-size{font-size: var(--wp--preset--font-size--x-large) !important;}
/*# sourceURL=global-styles-inline-css */
</style>

<link rel="stylesheet" href="https://hostalsolzamora.com/wp-content/cache/minify/4c431.css" media="all" />

<style id='contact-form-7-inline-css' type='text/css'>
.wpcf7 .wpcf7-recaptcha iframe {margin-bottom: 0;}.wpcf7 .wpcf7-recaptcha[data-align="center"] > div {margin: 0 auto;}.wpcf7 .wpcf7-recaptcha[data-align="right"] > div {margin: 0 0 0 auto;}
/*# sourceURL=contact-form-7-inline-css */
</style>
<link rel="stylesheet" href="https://hostalsolzamora.com/wp-content/cache/minify/38519.css" media="all" />

<link rel='stylesheet' id='font-awesome-official-css' href='https://use.fontawesome.com/releases/v5.15.4/css/all.css' type='text/css' media='all' integrity="sha384-DyZ88mC6Up2uqS4h/KRgHuoeGwBcD4Ng9SiP4dIRy0EXTlnuz47vAwmeGwVChigm" crossorigin="anonymous" />
<link rel='stylesheet' id='avegas-regular-css' href='https://fonts.googleapis.com/css2?family=Avegas+Regular%3Aital%2Cwght%400%2C300%3B0%2C400%3B0%2C500%3B0%2C600%3B0%2C700%3B1%2C300%3B1%2C400%3B1%2C500%3B1%2C600%3B1%2C700&#038;display=swap&#038;ver=6.9.4' type='text/css' media='all' />
<link rel='stylesheet' id='gotham-regular-css' href='https://fonts.googleapis.com/css2?family=Gotham+Regular%3Aital%2Cwght%400%2C300%3B0%2C400%3B0%2C500%3B0%2C600%3B0%2C700%3B1%2C300%3B1%2C400%3B1%2C500%3B1%2C600%3B1%2C700&#038;display=swap&#038;ver=6.9.4' type='text/css' media='all' />
<link rel="stylesheet" href="https://hostalsolzamora.com/wp-content/cache/minify/fd18d.css" media="all" />


<style id='jevelin-plugins-inline-css' type='text/css'>
body {}
/*# sourceURL=jevelin-plugins-inline-css */
</style>
<link rel="stylesheet" href="https://hostalsolzamora.com/wp-content/cache/minify/15215.css" media="all" />



<style id='jevelin-responsive-inline-css' type='text/css'>
.cf7-required:after,.woocommerce ul.products li.product a h3:hover,.woocommerce ul.products li.product ins,.post-title h2:hover,.sh-team:hover .sh-team-role,.sh-team-style4 .sh-team-role,.sh-team-style4 .sh-team-icon:hover i,.sh-header-search-submit,.woocommerce .woocommerce-tabs li.active a,.woocommerce .required,.sh-woocommerce-products-style3 .woocommerce ul.products li.product .add_to_cart_button:hover,.sh-woocommerce-products-style3 .woocommerce ul.products li.product .sh-woo-post-content-container .button:hover,.woocommerce .sh-woocommerce-products-style3 ul.products li.product .add_to_cart_button:hover,.woocommerce .sh-woocommerce-products-style3 ul.products li.product .sh-woo-post-content-container .button:hover,.woocommerce .sh-woocommerce-products-style3 ul.products li.product .woocommerce-loop-product__title:hover,.sh-jevelin-style3.woocommerce .product .product_meta .posted_in a,.sh-jevelin-style3 .sh-increase-numbers span:hover,.woocommerce div.product p.price,.woocomerce-styling li.product .amount,.post-format-icon,.sh-accent-color,.sh-blog-tag-item:hover h6,ul.page-numbers a:hover,.sh-portfolio-single-info-item i,.sh-filter-item.active,.sh-filter-item:hover,.sh-nav .sh-nav-cart li.menu-item-cart .mini_cart_item .amount,.sh-pricing-button-style3,#sidebar a:not(.sh-social-widgets-item):hover,.logged-in-as a:hover,.woocommerce table.shop_table.cart a:hover,.wrap-forms sup:before,.sh-comment-date a:hover,.reply a.comment-edit-link,.comment-respond #cancel-comment-reply-link,.sh-portfolio-title:hover,.sh-portfolio-single-related-mini h5:hover,.sh-header-top-10 .header-contacts-details-large-icon i,.sh-unyson-frontend-test.active,.plyr--full-ui input[type=range],.woocommerce td.woocommerce-grouped-product-list-item__label a:hover,.sh-accent-color-hover:hover {color: #687e56!important;}.sh-jevelin-style3 .woocommerce-form-coupon-toggle .sh-alert,.sh-jevelin-style3 .woocommerce-progress.step1 .woocommerce-header-item-cart,.sh-jevelin-style3 .woocommerce-progress.step2 .woocommerce-header-item-checkout,.sh-dropcaps-full-square,.sh-dropcaps-full-square-border,.masonry2 .post-content-container a.post-meta-comments:hover,.sh-header-builder-edit:hover {background-color: #687e56;}.contact-form input[type="submit"],.sh-back-to-top:hover,.sh-dropcaps-full-square-tale,.sh-404-button,.woocommerce .wc-forward,.woocommerce .checkout-button,.woocommerce div.product form.cart button,.woocommerce .button:not(.add_to_cart_button),.sh-blog-tag-item,.sh-comments .submit,.sh-sidebar-search-active .search-field,.sh-nav .sh-nav-cart .buttons a.checkout,ul.page-numbers .current,ul.page-numbers .current:hover,.post-background,.post-item .post-category .post-category-list,.cart-icon span,.comment-input-required,.widget_tag_cloud a:hover,.widget_product_tag_cloud a:hover,.woocommerce #respond input#submit,.sh-portfolio-overlay1-bar,.sh-pricing-button-style4,.sh-pricing-button-style11,.sh-revslider-button2,.sh-portfolio-default2 .sh-portfolio-title,.sh-recent-posts-widgets-count,.sh-filter-item.active:after,.blog-style-largedate .post-comments,.sh-video-player-style1 .sh-video-player-image-play,.sh-video-player-style2 .sh-video-player-image-play:hover,.sh-video-player-style2 .sh-video-player-image-play:focus,.woocommerce .woocommerce-tabs li a:after,.sh-image-gallery .slick-dots li.slick-active button,.sh-recent-posts-carousel .slick-dots li.slick-active button,.sh-recent-products-carousel .slick-dots li.slick-active button,.sh-settings-container-bar .sh-progress-status-value,.post-password-form input[type="submit"],.wpcf7-form .wpcf7-submit,.sh-portfolio-filter-style3 .sh-filter-item.active .sh-filter-item-content,.sh-portfolio-filter-style4 .sh-filter-item:hover .sh-filter-item-content,.sh-woocommerce-categories-count,.sh-woocommerce-products-style2 .woocommerce ul.products li.product .add_to_cart_button:hover,.woocomerce-styling.sh-woocommerce-products-style2 ul.products li.product .add_to_cart_button:hover,.sh-icon-group-style2 .sh-icon-group-item:hover,.sh-text-background,.plyr--audio .plyr__control.plyr__tab-focus,.plyr--audio .plyr__control:hover,.plyr--audio .plyr__control[aria-expanded=true],.sh-jevelin-style3 .widget_price_filter .ui-slider .ui-slider-range {background-color: #687e56!important;}.sh-cf7-style4 form input:not(.wpcf7-submit):focus {border-bottom-color: #687e56;}::selection {background-color: #687e56!important;color: #fff;}::-moz-selection {background-color: #687e56!important;color: #fff;}.woocommerce .woocommerce-tabs li.active a {border-bottom-color: #687e56!important;}#header-quote,.sh-dropcaps-full-square-tale:after,.sh-blog-tag-item:after,.widget_tag_cloud a:hover:after,.widget_product_tag_cloud a:hover:after {border-left-color: #687e56!important;}.cart-icon .cart-icon-triangle-color {border-right-color: #687e56!important;}.sh-back-to-top:hover,.widget_price_filter .ui-slider .ui-slider-handle,.sh-sidebar-search-active .search-field:hover,.sh-sidebar-search-active .search-field:focus,.sh-cf7-style2 form p input:not(.wpcf7-submit):focus,.sh-cf7-style2 form p textarea:focus,.sh-jevelin-style3 .order-total .woocommerce-Price-amount {border-color: #687e56!important;}.post-item .post-category .arrow-right {border-left-color: #687e56;}.woocommerce .wc-forward:hover,.woocommerce .button:not(.add_to_cart_button):hover,.woocommerce .checkout-button:hover,.woocommerce #respond input#submit:hover,.contact-form input[type="submit"]:hover,.wpcf7-form .wpcf7-submit:hover,.sh-video-player-image-play:hover,.sh-404-button:hover,.post-password-form input[type="submit"],.sh-pricing-button-style11:hover,.sh-revslider-button2.spacing-animation:not(.inverted):hover {background-color: #687e56!important;}.sh-cf7-unyson form .wpcf7-submit {background-size: 200% auto;background-image: linear-gradient(to right, #687e56 , #687e56, #687e56);}.sh-mini-overlay-container,.sh-portfolio-overlay-info-box,.sh-portfolio-overlay-bottom .sh-portfolio-icon,.sh-portfolio-overlay-bottom .sh-portfolio-text,.sh-portfolio-overlay2-bar,.sh-portfolio-overlay2-data,.sh-portfolio-overlay3-data {background-color: rgba(104,126,86,0.75)!important;}.woocommerce-progress {background-color: rgba(104,126,86,0.07);}.woocommerce-progress-item {color: rgba(104,126,86,0.5);}.sh-jevelin-style3 .sh-increase-numbers span:hover,.widget_price_filter .price_slider_wrapper .ui-widget-content {background-color: rgba(104,126,86,0.12)!important;}.widget_price_filter .ui-slider .ui-slider-range {background-color: rgba(104,126,86,0.5)!important;}.sh-team-social-overlay2 .sh-team-image:hover .sh-team-overlay2,.sh-overlay-style1,.sh-portfolio-overlay4 {background-color: rgba(104,126,86,0.8)!important;}.sh-header .sh-nav > .current_page_item > a,.sh-header .sh-nav > .current-menu-ancestor > a,.sh-header .sh-nav > .current-menu-item > a,.sh-header-left-side .sh-nav > .current_page_item > a {color: #687e56!important;}.sh-popover-mini:not(.sh-popover-mini-dark) {background-color: #687e56;}.sh-popover-mini:not(.sh-popover-mini-dark):before {border-color: transparent transparent #687e56 #687e56!important;}.sh-footer .sh-footer-widgets a:hover,.sh-footer .sh-footer-widgets li a:hover,.sh-footer .sh-footer-widgets h6:hover {color: #ffffff;}
/*# sourceURL=jevelin-responsive-inline-css */
</style>
<link rel="stylesheet" href="https://hostalsolzamora.com/wp-content/cache/minify/be0de.css" media="all" />




<link rel='stylesheet' id='jevelin-default-font-css' href='https://fonts.googleapis.com/css?family=Raleway%3A400%2C700&#038;ver=6.9.4' type='text/css' media='all' />
<link rel='stylesheet' id='jevelin-default-font2-css' href='https://fonts.googleapis.com/css?family=Montserrat%3A400%2C700&#038;ver=6.9.4' type='text/css' media='all' />
<link rel="stylesheet" href="https://hostalsolzamora.com/wp-content/cache/minify/1b4bd.css" media="all" />

<link rel="preload" as="style" href="https://fonts.googleapis.com/css?family=Montserrat:400,700%7CRaleway:400&#038;display=swap&#038;ver=1681641683" /><link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat:400,700%7CRaleway:400&#038;display=swap&#038;ver=1681641683" media="print" onload="this.media='all'"><noscript><link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat:400,700%7CRaleway:400&#038;display=swap&#038;ver=1681641683" /></noscript><link rel='stylesheet' id='font-awesome-official-v4shim-css' href='https://use.fontawesome.com/releases/v5.15.4/css/v4-shims.css' type='text/css' media='all' integrity="sha384-Vq76wejb3QJM4nDatBa5rUOve+9gkegsjCebvV/9fvXlGWo4HCMR4cJZjjcF6Viv" crossorigin="anonymous" />
<style id='font-awesome-official-v4shim-inline-css' type='text/css'>
@font-face {
font-family: "FontAwesome";
font-display: block;
src: url("https://use.fontawesome.com/releases/v5.15.4/webfonts/fa-brands-400.eot"),
		url("https://use.fontawesome.com/releases/v5.15.4/webfonts/fa-brands-400.eot?#iefix") format("embedded-opentype"),
		url("https://use.fontawesome.com/releases/v5.15.4/webfonts/fa-brands-400.woff2") format("woff2"),
		url("https://use.fontawesome.com/releases/v5.15.4/webfonts/fa-brands-400.woff") format("woff"),
		url("https://use.fontawesome.com/releases/v5.15.4/webfonts/fa-brands-400.ttf") format("truetype"),
		url("https://use.fontawesome.com/releases/v5.15.4/webfonts/fa-brands-400.svg#fontawesome") format("svg");
}

@font-face {
font-family: "FontAwesome";
font-display: block;
src: url("https://use.fontawesome.com/releases/v5.15.4/webfonts/fa-solid-900.eot"),
		url("https://use.fontawesome.com/releases/v5.15.4/webfonts/fa-solid-900.eot?#iefix") format("embedded-opentype"),
		url("https://use.fontawesome.com/releases/v5.15.4/webfonts/fa-solid-900.woff2") format("woff2"),
		url("https://use.fontawesome.com/releases/v5.15.4/webfonts/fa-solid-900.woff") format("woff"),
		url("https://use.fontawesome.com/releases/v5.15.4/webfonts/fa-solid-900.ttf") format("truetype"),
		url("https://use.fontawesome.com/releases/v5.15.4/webfonts/fa-solid-900.svg#fontawesome") format("svg");
}

@font-face {
font-family: "FontAwesome";
font-display: block;
src: url("https://use.fontawesome.com/releases/v5.15.4/webfonts/fa-regular-400.eot"),
		url("https://use.fontawesome.com/releases/v5.15.4/webfonts/fa-regular-400.eot?#iefix") format("embedded-opentype"),
		url("https://use.fontawesome.com/releases/v5.15.4/webfonts/fa-regular-400.woff2") format("woff2"),
		url("https://use.fontawesome.com/releases/v5.15.4/webfonts/fa-regular-400.woff") format("woff"),
		url("https://use.fontawesome.com/releases/v5.15.4/webfonts/fa-regular-400.ttf") format("truetype"),
		url("https://use.fontawesome.com/releases/v5.15.4/webfonts/fa-regular-400.svg#fontawesome") format("svg");
unicode-range: U+F004-F005,U+F007,U+F017,U+F022,U+F024,U+F02E,U+F03E,U+F044,U+F057-F059,U+F06E,U+F070,U+F075,U+F07B-F07C,U+F080,U+F086,U+F089,U+F094,U+F09D,U+F0A0,U+F0A4-F0A7,U+F0C5,U+F0C7-F0C8,U+F0E0,U+F0EB,U+F0F3,U+F0F8,U+F0FE,U+F111,U+F118-F11A,U+F11C,U+F133,U+F144,U+F146,U+F14A,U+F14D-F14E,U+F150-F152,U+F15B-F15C,U+F164-F165,U+F185-F186,U+F191-F192,U+F1AD,U+F1C1-F1C9,U+F1CD,U+F1D8,U+F1E3,U+F1EA,U+F1F6,U+F1F9,U+F20A,U+F247-F249,U+F24D,U+F254-F25B,U+F25D,U+F267,U+F271-F274,U+F279,U+F28B,U+F28D,U+F2B5-F2B6,U+F2B9,U+F2BB,U+F2BD,U+F2C1-F2C2,U+F2D0,U+F2D2,U+F2DC,U+F2ED,U+F328,U+F358-F35B,U+F3A5,U+F3D1,U+F410,U+F4AD;
}
/*# sourceURL=font-awesome-official-v4shim-inline-css */
</style>
<!--n2css--><!--n2js--><script src="https://hostalsolzamora.com/wp-content/cache/minify/2917c.js"></script>



<script type="text/javascript" id="jevelin-scripts-js-extra">
/* <![CDATA[ */
var jevelin_loadmore_posts = {"ajax_url":"https://hostalsolzamora.com/wp-admin/admin-ajax.php"};
var jevelin = {"page_loader":"0","notice":"","header_animation_dropdown_delay":"1000","header_animation_dropdown":"easeOutQuint","header_animation_dropdown_speed":"300","lightbox_opacity":"0.88","lightbox_transition":"elastic","lightbox_window_max_width":"1200","lightbox_window_max_height":"1200","lightbox_window_size":"0.8","page_numbers_prev":"Previous","page_numbers_next":"Next","rtl_support":"","footer_parallax":"","one_pager":"1","wc_lightbox":"jevelin","quantity_button":"on","anchor_scroll_speed":"1000"};
//# sourceURL=jevelin-scripts-js-extra
/* ]]> */
</script>
<script src="https://hostalsolzamora.com/wp-content/cache/minify/c899e.js"></script>



<!-- Google tag (gtag.js) snippet added by Site Kit -->
<!-- Fragmento de código de Google Analytics añadido por Site Kit -->
<script type="text/javascript" src="https://www.googletagmanager.com/gtag/js?id=G-12HKKYMEQ2" id="google_gtagjs-js" async></script>
<script type="text/javascript" id="google_gtagjs-js-after">
/* <![CDATA[ */
window.dataLayer = window.dataLayer || [];function gtag(){dataLayer.push(arguments);}
gtag("set","linker",{"domains":["hostalsolzamora.com"]});
gtag("js", new Date());
gtag("set", "developer_id.dZTNiMT", true);
gtag("config", "G-12HKKYMEQ2");
//# sourceURL=google_gtagjs-js-after
/* ]]> */
</script>
<script src="https://hostalsolzamora.com/wp-content/cache/minify/cabb0.js"></script>

<link rel="https://api.w.org/" href="https://hostalsolzamora.com/wp-json/" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://hostalsolzamora.com/xmlrpc.php?rsd" />
<meta name="generator" content="WordPress 6.9.4" />
<meta name="generator" content="Redux 4.5.10" /><meta name="generator" content="Site Kit by Google 1.171.0" /><meta name="generator" content="performance-lab 4.0.1; plugins: ">
			<style>.cmplz-hidden {
					display: none !important;
				}</style><meta name="generator" content="Powered by WPBakery Page Builder - drag and drop page builder for WordPress."/>
<link rel="icon" href="https://hostalsolzamora.com/wp-content/uploads/2022/03/cropped-Logotipos-HS-74-32x32.png" sizes="32x32" />
<link rel="icon" href="https://hostalsolzamora.com/wp-content/uploads/2022/03/cropped-Logotipos-HS-74-192x192.png" sizes="192x192" />
<link rel="apple-touch-icon" href="https://hostalsolzamora.com/wp-content/uploads/2022/03/cropped-Logotipos-HS-74-180x180.png" />
<meta name="msapplication-TileImage" content="https://hostalsolzamora.com/wp-content/uploads/2022/03/cropped-Logotipos-HS-74-270x270.png" />
			<noscript><style> .wpb_animate_when_almost_visible { opacity: 1; }</style></noscript><style id="yellow-pencil">
/*
	The following CSS codes are created by the YellowPencil plugin.
	https://yellowpencil.waspthemes.com/
*/
#menu-standard-navigation .menu-item a{font-family:'Avegas Regular' !important;font-weight:100;font-size:19px !important;letter-spacing:5px;}.sh-header .sh-nav > .current_page_item > a, .sh-header .sh-nav > .current-menu-ancestor > a, .sh-header .sh-nav > .current-menu-item > a, .sh-header-left-side .sh-nav > .current_page_item > a{font-weight: 800 !important;}.sh-header-top p{text-align:center;}.primary-desktop .header-logo .sh-table-cell{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-box-pack:center;-ms-flex-pack:center;justify-content:center;}#page-container .sh-header-height .sh-header{border-top-style:solid;border-bottom-color:#687e56;}header.primary-desktop{height: 285px !important;}#page-container div .sh-header-top:nth-child(2){background-color:#ffffff !important;}.blanco{color: #fff !important;}h1, h2, h3, h4, h5, h6{font-weight: 400 !important;}.vc_tta-panels .vc_tta-panel .vc_tta-panel-heading{background-color:transparent !important;border-top-style:none !important;border-right-style:none !important;border-left-style:none !important;border-bottom-width:1px !important;border-bottom-color:#687E56 !important;}#acordeon a span{color:#687e56;font-family: 'Gotham Regular' !important;text-transform: uppercase;font-size:14px;}#acordeon a span:hover{color:#687e56;}.vc_tta-color-vista-blue.vc_tta-style-outline .vc_tta-controls-icon::after, .vc_tta-color-vista-blue.vc_tta-style-outline .vc_tta-controls-icon::before{border-color: #687E56 !important;}.vc_tta-color-vista-blue.vc_tta-style-outline .vc_tta-panel .vc_tta-panel-body, .vc_tta-color-vista-blue.vc_tta-style-outline .vc_tta-panel .vc_tta-panel-body::after, .vc_tta-color-vista-blue.vc_tta-style-outline .vc_tta-panel .vc_tta-panel-body::before{border-color: transparent !important;}#block-8 p .fas, .fab{margin-right:10px;}#menu-footer .menu-item{border-bottom-style:none;}.wp-block-image .size-large img{max-width:66%;}#block-7 .wp-block-image .size-large{text-align:center;}#wrapper .sh-footer .sh-footer-widgets{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-box-pack:center;-ms-flex-pack:center;justify-content:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;padding-top:0px;padding-bottom:0px;}.sh-footer-widgets .sh-footer-columns{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-box-align:center;-ms-flex-align:center;align-items:center;}#menu-footer .menu-item a{font-family:'Avegas Regular' !important;font-size:15px;line-height:0.5em;}#block-8 p a{font-size:15px;font-family:'Avegas Regular';}.sh-footer-widgets .sh-footer-columns .widget-item:nth-child(1){padding-left:10%;}img.sh-standard-logo{height: 150px;}.sh-nav li.menu-item{float: left;padding: 0 30px;border-bottom: 0px solid transparent;}.wpb_wrapper .vc_separator h4{font-size: 24px;padding-left:50px;padding-right:50px;}.primary-desktop .sh-header{border-top-width:1px;border-bottom-width:1px;}#header-navigation .sh-nav-container{padding-top:10px;padding-bottom:10px;}#menu-standard-navigation .menu-item:nth-child(7){padding-left:0px;}#menu-standard-navigation .menu-item:nth-child(6){padding-right:0px;}#menu-standard-navigation .menu-item:nth-child(6) a{padding-right:15px;}#block-8 p{line-height:0.5em;}#block-8 p:nth-child(5) a{text-decoration:underline;}#block-8{margin-bottom:40px;}.sh-copyrights .sh-table-full span{font-family:'Avegas Regular' !important;color:#687e56;font-size:17px;}.sh-copyrights-text span a{color:#687e56 !important;}.primary-desktop .sh-header-top p{font-family:'Avegas Regular' !important;font-size:17px;}.marquee-content span span{margin-bottom:-10px;}#punto{font-size: 25px !important;width: 1px !important;}@media (max-width:1024px){.sh-group .header-logo .sh-standard-logo{max-width:25%;}.sh-header-mobile-dropdown .menu-item:nth-child(6) .menu-item-open-fix{display:none;}.sh-header-mobile-dropdown .menu-item:nth-child(6) a:nth-child(2){display:none;}.sh-header-mobile-dropdown .menu-item:nth-child(7) .menu-item-open-fix{display:none;}.sh-header-mobile-dropdown .menu-item:nth-child(7) a:nth-child(2){display:none;}.sh-nav-mobile .menu-item .menu-item-open-fix{font-family:'Avegas Regular' !important;letter-spacing:3px;}.sh-header-mobile-dropdown ul{padding-bottom:40px !important;}.header-logo .sh-table-cell .sh-standard-logo{content: url("https://hostalsolzamora.com/wp-content/uploads/2022/03/vertical-e1646224212133.png");}}@media (max-width:991px){#wrapper .sh-footer .sh-footer-widgets{padding-top:17px;padding-bottom:17px;}}@media (max-width:900px){#wrapper .sh-footer .sh-footer-widgets{padding-top:22px;padding-bottom:22px;}.sh-footer-widgets .sh-footer-columns .widget-item{padding-left:0px !important;}#block-8{padding-right:0px;}#block-7{padding-right:0px;}}@media (max-width:800px){#block-8{font-size:11px;}#wrapper .sh-footer .sh-copyrights{padding-top:0px;padding-bottom:0px;}.vc_custom_1647688180955 .wpb_row:nth-child(2) .vc_column_container:nth-child(1){margin-bottom:-19px;}}@media (max-width:767px){.sh-group .header-logo .sh-standard-logo{max-width:50%;position:relative;left:-10%;}}@media (max-width:640px){.sh-footer-widgets .sh-footer-columns{display:block;}#wrapper .sh-footer .sh-footer-widgets{padding-top:15px;padding-bottom:15px;}.sh-footer-widgets .sh-footer-columns .widget-item{padding-left:0px !important;text-align:center;text-align:center;}#wrapper .sh-footer .sh-copyrights{padding-top:0px;padding-bottom:0px;}.wp-block-image .size-large img{max-width:55%;}#content .vc_custom_1646399440460{margin-top:52px !important;}.vc_custom_1646344620365 .wpb_wrapper .vc_separator{margin-left:0px;margin-right:0px !important;}.vc_custom_1646344620365 .wpb_wrapper{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-box-pack:center;-ms-flex-pack:center;justify-content:center;}.vc_custom_1646344620365 .vc_column-inner{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-box-pack:center;-ms-flex-pack:center;justify-content:center;padding-left:0px;padding-right:0px;}}@media (max-width:550px){.sh-group .header-logo .sh-standard-logo{max-width:70%;}}@media (min-width:801px){.sh-copyrights .sh-table-full > .sh-table-cell:nth-child(1){display:none;}.sh-copyrights .sh-table-full .sh-table-cell:nth-child(3){display:none;}}
</style><link rel="stylesheet" href="https://hostalsolzamora.com/wp-content/cache/minify/a5e3e.css" media="all" />


</head>
<body data-cmplz=2 class="error404 wp-theme-jevelin wp-child-theme-jevelin-child non-logged-in wpb-js-composer js-comp-ver-6.8.0 vc_responsive modula-best-grid-gallery sh-header-mobile-spacing-compact sh-body-header-sticky sh-blog-style2 sh-woocommerce-style3 carousel-dot-style1 carousel-dot-spacing-5px carousel-dot-size-standard">


	
	<div id="page-container" class="">
		

									
					<div role="banner" itemscope="itemscope" itemtype="http://schema.org/WPHeader">
						<header class="primary-mobile">
							
<div id="header-mobile" class="sh-header-mobile">
	<div class="sh-header-mobile-navigation">
		

		<div class="container">
			<div class="sh-table">
				<div class="sh-table-cell sh-group">

										            <div class="header-logo sh-group-equal">
                <a href="https://hostalsolzamora.com/" class="header-logo-container sh-table-small" rel="home">
                    
                        <div class="sh-table-cell">
                            <img class="sh-standard-logo" src="https://hostalsolzamora.com/wp-content/uploads/2022/03/Logotipo-header_Mesa-de-trabajo-1-copia.svg" alt="Hostal Sol Zamora" />
                            <img class="sh-sticky-logo" src="https://hostalsolzamora.com/wp-content/uploads/2022/03/Logotipo-header_Mesa-de-trabajo-1-copia.svg" alt="Hostal Sol Zamora" />
                            <img class="sh-light-logo" src="https://hostalsolzamora.com/wp-content/uploads/2022/03/vertical-e1646224212133.png" alt="Hostal Sol Zamora" />
                        </div>

                                    </a>
            </div>

    
				</div>
				<div class="sh-table-cell">

										<nav id="header-navigation-mobile" class="header-standard-position">
						<div class="sh-nav-container">
							<ul class="sh-nav">

															    
        <li class="menu-item sh-nav-dropdown">
            <a>
            <div class="sh-table-full">
                <div class="sh-table-cell">
                    <span class="c-hamburger c-hamburger--htx">
                        <span>Toggle menu</span>
                    </span>
                </div>
            </div></a>
        </li>
							</ul>
						</div>
					</nav>

				</div>
			</div>
		</div>
	</div>

	<nav class="sh-header-mobile-dropdown">
		<div class="container sh-nav-container">
			<ul class="sh-nav-mobile"></ul>
		</div>

		<div class="container sh-nav-container">
					</div>

			</nav>
</div>
						</header>
						<header class="primary-desktop">
							


<script>
function ejecutar(argument) {
  window.alert("⚠️El servicio de 🚧reservas online 🚧 está teniendo problemas, llámanos al 639980253 para confirmar tu reserva.");
}
 
//window.addEventListener("onload", ejecutar);
//window.addEventListener("load", ejecutar);
//if (document.readyState === "complete") { ejecutar();}
</script>

	<div class="sh-header-top sh-header-top-4">
		<div class="container">

												
			<p>Reserva en nuestra web y consigue un descuento <a href="/reserva" style="text-decoration-line: underline;">RESERVA ONLINE AQUÍ</a>  (<a onclick="alert('Código Promocional WEB\nCódigo promocional solo disponible a través de nuestra web, las reserva utilizando este código a través de otros sistemas de reservas serán canceladas. Codigo promocional válido durante 2024. El precio de la web no tiene porque coincidir con el precio por teléfono u otros canales web.')" style="text-decoration-line: underline;">condiciones</a>) .</p>
			
			
		</div>
	</div>

	<div class="sh-header-top sh-header-top-4">
		<div class="container">

						            <div class="header-logo sh-group-equal">
                <a href="https://hostalsolzamora.com/" class="header-logo-container sh-table-small" rel="home">
                    
                        <div class="sh-table-cell">
                            <img class="sh-standard-logo" src="https://hostalsolzamora.com/wp-content/uploads/2022/03/Logotipo-header_Mesa-de-trabajo-1-copia.svg" alt="Hostal Sol Zamora" />
                            <img class="sh-sticky-logo" src="https://hostalsolzamora.com/wp-content/uploads/2022/03/Logotipo-header_Mesa-de-trabajo-1-copia.svg" alt="Hostal Sol Zamora" />
                            <img class="sh-light-logo" src="https://hostalsolzamora.com/wp-content/uploads/2022/03/vertical-e1646224212133.png" alt="Hostal Sol Zamora" />
                        </div>

                                    </a>
            </div>

    
		</div>
	</div>



<div class="sh-header-height">
	<div class="sh-header sh-header-4 sh-sticky-header">
		<div class="container">

						<div class="container">

			

			</div>
			<nav id="header-navigation" class="header-standard-position">
									<div class="sh-nav-container"><ul id="menu-standard-navigation" class="sh-nav"><li id="menu-item-36" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-36"><a href = "https://hostalsolzamora.com/">Inicio</a></li>
<li id="menu-item-35" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-35"><a href = "https://hostalsolzamora.com/habitaciones">Habitaciones</a></li>
<li id="menu-item-523" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-523"><a href = "https://hostalsolzamora.com/parking">Parking</a></li>
<li id="menu-item-34" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-34"><a href = "https://hostalsolzamora.com/sobre-nosotros-cercania">Nosotros</a></li>
<li id="menu-item-33" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-33"><a href = "https://hostalsolzamora.com/reserva">Reserva</a></li>
<li id="menu-item-32" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-32"><a href = "https://hostalsolzamora.com/contacto">Contacto</a></li>
<li id="menu-item-121" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-121"><a href = "https://www.instagram.com/hostalsolzamora/"><!-- <i class="fab fa-instagram"></i> --></a></li>
<li id="menu-item-122" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-122"><a href = "https://www.facebook.com/hostalsolzam"><!-- <i class="fab fa-facebook-f"></i> --></a></li>
</ul></div>							</nav>

		</div>
		
<div  id="header-search" class="sh-header-search">
	<div class="sh-table-full">
		<div class="sh-table-cell">

			<div class="line-test">
				<div class="container">

					<form method="get" class="sh-header-search-form" action="https://hostalsolzamora.com/">
						<input type="search" class="sh-header-search-input" placeholder="Search Here.." value="" name="s" required />
						<button type="submit" class="sh-header-search-submit">
							<i class="icon-magnifier"></i>
						</button>
						<div class="sh-header-search-close close-header-search">
							<i class="ti-close"></i>
						</div>

											</form>

				</div>
			</div>

		</div>
	</div>
</div>
	</div>
</div>
						</header>
					</div>

							
					

		

        

			<div id="wrapper">
				

				<div class="content-container sh-page-layout-default">
									<div class="container entry-content">
				
				

	
		<div id="sh-404" class="sh-404 sh-table">
			<div class="sh-table-cell">
				<span class="sh-404-title">4</span>
			</div>
			<div class="sh-table-cell">
				<span class="sh-404-title">0</span>
				<div>
					<h3>Oops, This Page Could Not Be Found!</h3>
					<p>The page you are looking for might have been removed, had its name changed, or is temporarily unavailable.</p>
					<a href="" class="sh-404-button">
						<i class="fa fa-refresh"></i>
						Reload					</a>
				</div>
			</div>
			<div class="sh-table-cell">
				<span class="sh-404-title">4</span>
			</div>
		</div>

		<div id="sh-404-mobile" class="sh-404">
			<div class="sh-table-cell">
				<span class="sh-404-title sh-404-mobile-title">404</span>
				<div>
					<h3>Oops, This Page Could Not Be Found!</h3>
					<p>The page you are looking for might have been removed, had its name changed, or is temporarily unavailable.</p>
					<a href="" class="sh-404-button">
						<i class="fa fa-refresh"></i>
						Reload					</a>
				</div>
			</div>
		</div>

	

			</div>
		</div>

					
				<footer class="sh-footer" role="contentinfo" itemscope="itemscope" itemtype="http://schema.org/WPFooter">
					
						<div class="sh-footer-widgets">
							<div class="container">
								<div class="sh-footer-columns">
									<div id="nav_menu-2" class="widget-item widget_nav_menu"><div class="menu-footer-container"><ul id="menu-footer" class="menu"><li id="menu-item-79" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-79"><a href = "https://hostalsolzamora.com/">Inicio</a></li>
<li id="menu-item-82" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-82"><a href = "https://hostalsolzamora.com/habitaciones">Nuestras habitaciones</a></li>
<li id="menu-item-84" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-84"><a href = "https://hostalsolzamora.com/sobre-nosotros-cercania">Sobre nosotros</a></li>
<li id="menu-item-83" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-83"><a href = "https://hostalsolzamora.com/reserva">Reserva</a></li>
<li id="menu-item-81" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-81"><a href = "https://hostalsolzamora.com/contacto">Contacto</a></li>
<li id="menu-item-129" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-129"><a href = "https://hostalsolzamora.com/politica-de-cookies-ue">Política de cookies (UE)</a></li>
<li id="menu-item-132" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-132"><a href = "https://hostalsolzamora.com/terminos-y-condiciones">Términos y condiciones</a></li>
</ul></div></div><div id="block-7" class="widget-item widget_block widget_media_image"><div class="wp-block-image">
<figure class="aligncenter size-large is-resized"><img loading="lazy" decoding="async" src="https://hostalsolzamora.com/wp-content/uploads/2022/03/isotipo-1024x1024.png" alt="" class="wp-image-85" width="438" height="438" srcset="https://hostalsolzamora.com/wp-content/uploads/2022/03/isotipo-1024x1024.png 1024w, https://hostalsolzamora.com/wp-content/uploads/2022/03/isotipo-300x300.png 300w, https://hostalsolzamora.com/wp-content/uploads/2022/03/isotipo-150x150.png 150w, https://hostalsolzamora.com/wp-content/uploads/2022/03/isotipo-768x768.png 768w, https://hostalsolzamora.com/wp-content/uploads/2022/03/isotipo-1536x1536.png 1536w, https://hostalsolzamora.com/wp-content/uploads/2022/03/isotipo-2048x2048.png 2048w, https://hostalsolzamora.com/wp-content/uploads/2022/03/isotipo-660x660.png 660w" sizes="auto, (max-width: 438px) 100vw, 438px" /></figure>
</div></div><div id="block-8" class="widget-item widget_block"><p><i class="fas fa-envelope"></i><a href="mailto:hostalsol@outlook.com">hostalsol@outlook.com</a></p>
<p><i class="fas fa-phone"></i><a href="tel:+34980533152">980533152</a> / <a href="tel:+34639980253">639980253</a></p>
<p><i class="fab fa-instagram"></i><a href="https://www.instagram.com/hostalsolzamora/">@hostalsolzamora</a></p>
<p><i class="fab fa-facebook-f"></i><a href="https://www.facebook.com/hostalsolzam">Hostal Sol</a></p>
<p><i class="fas fa-map-marker-alt"></i><a href="https://goo.gl/maps/689g4UmPLFAGKsEq8">Calle Benavente, 2 - 3º</a></p></div>								</div>
							</div>
						</div>

											<div class="sh-copyrights">
		<div class="container container-padding">
			
				<div class="sh-copyrights-style3">
					<div class="sh-table-full text-left">
						<div class="sh-copyrights-style3-item sh-table-cell">
													</div>
						<div class="sh-copyrights-style3-item sh-table-cell text-center">
							
<div class="sh-copyrights-text">
	<span class="developer-copyrights  sh-hidden">
		WordPress Theme built by <a href="https://shufflehound.com" target="blank"><strong>Shufflehound</strong>.</a>
		</span>
	<span>Diseñado por <a href="http://monnedesign.com">Monné Design</a></span>
</div>						</div>
						<div class="sh-copyrights-style3-item sh-table-cell text-right">
															<div class="sh-table-cell">
									<div class="sh-copyrights-social">
																			</div>
								</div>
													</div>
					</div>
				</div>


			
		</div>
	</div>
				</footer>

						</div>
</div>




<script type="speculationrules">
{"prefetch":[{"source":"document","where":{"and":[{"href_matches":"/*"},{"not":{"href_matches":["/wp-*.php","/wp-admin/*","/wp-content/uploads/*","/wp-content/*","/wp-content/plugins/*","/wp-content/themes/jevelin-child/*","/wp-content/themes/jevelin/*","/*\\?(.+)"]}},{"not":{"selector_matches":"a[rel~=\"nofollow\"]"}},{"not":{"selector_matches":".no-prefetch, .no-prefetch a"}}]},"eagerness":"conservative"}]}
</script>
        <script>
            // Do not change this comment line otherwise Speed Optimizer won't be able to detect this script

            (function () {
                function sendRequest(url, body) {
                    if(!window.fetch) {
                        const xhr = new XMLHttpRequest();
                        xhr.open("POST", url, true);
                        xhr.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
                        xhr.send(JSON.stringify(body))
                        return
                    }

                    const request = fetch(url, {
                        method: 'POST',
                        body: JSON.stringify(body),
                        keepalive: true,
                        headers: {
                            'Content-Type': 'application/json;charset=UTF-8'
                        }
                    });
                }

                const calculateParentDistance = (child, parent) => {
                    let count = 0;
                    let currentElement = child;

                    // Traverse up the DOM tree until we reach parent or the top of the DOM
                    while (currentElement && currentElement !== parent) {
                        currentElement = currentElement.parentNode;
                        count++;
                    }

                    // If parent was not found in the hierarchy, return -1
                    if (!currentElement) {
                        return -1; // Indicates parent is not an ancestor of element
                    }

                    return count; // Number of layers between element and parent
                }
                const isMatchingClass = (linkRule, href, classes, ids) => {
                    return classes.includes(linkRule.value)
                }
                const isMatchingId = (linkRule, href, classes, ids) => {
                    return ids.includes(linkRule.value)
                }
                const isMatchingDomain = (linkRule, href, classes, ids) => {
                    if(!URL.canParse(href)) {
                        return false
                    }

                    const url = new URL(href)
                    const host = url.host
                    const hostsToMatch = [host]

                    if(host.startsWith('www.')) {
                        hostsToMatch.push(host.substring(4))
                    } else {
                        hostsToMatch.push('www.' + host)
                    }

                    return hostsToMatch.includes(linkRule.value)
                }
                const isMatchingExtension = (linkRule, href, classes, ids) => {
                    if(!URL.canParse(href)) {
                        return false
                    }

                    const url = new URL(href)

                    return url.pathname.endsWith('.' + linkRule.value)
                }
                const isMatchingSubdirectory = (linkRule, href, classes, ids) => {
                    if(!URL.canParse(href)) {
                        return false
                    }

                    const url = new URL(href)

                    return url.pathname.startsWith('/' + linkRule.value + '/')
                }
                const isMatchingProtocol = (linkRule, href, classes, ids) => {
                    if(!URL.canParse(href)) {
                        return false
                    }

                    const url = new URL(href)

                    return url.protocol === linkRule.value + ':'
                }
                const isMatchingExternal = (linkRule, href, classes, ids) => {
                    if(!URL.canParse(href) || !URL.canParse(document.location.href)) {
                        return false
                    }

                    const matchingProtocols = ['http:', 'https:']
                    const siteUrl = new URL(document.location.href)
                    const linkUrl = new URL(href)

                    // Links to subdomains will appear to be external matches according to JavaScript,
                    // but the PHP rules will filter those events out.
                    return matchingProtocols.includes(linkUrl.protocol) && siteUrl.host !== linkUrl.host
                }
                const isMatch = (linkRule, href, classes, ids) => {
                    switch (linkRule.type) {
                        case 'class':
                            return isMatchingClass(linkRule, href, classes, ids)
                        case 'id':
                            return isMatchingId(linkRule, href, classes, ids)
                        case 'domain':
                            return isMatchingDomain(linkRule, href, classes, ids)
                        case 'extension':
                            return isMatchingExtension(linkRule, href, classes, ids)
                        case 'subdirectory':
                            return isMatchingSubdirectory(linkRule, href, classes, ids)
                        case 'protocol':
                            return isMatchingProtocol(linkRule, href, classes, ids)
                        case 'external':
                            return isMatchingExternal(linkRule, href, classes, ids)
                        default:
                            return false;
                    }
                }
                const track = (element) => {
                    const href = element.href ?? null
                    const classes = Array.from(element.classList)
                    const ids = [element.id]
                    const linkRules = [{"type":"extension","value":"pdf"},{"type":"extension","value":"zip"},{"type":"protocol","value":"mailto"},{"type":"protocol","value":"tel"}]
                    if(linkRules.length === 0) {
                        return
                    }

                    // For link rules that target an id, we need to allow that id to appear
                    // in any ancestor up to the 7th ancestor. This loop looks for those matches
                    // and counts them.
                    linkRules.forEach((linkRule) => {
                        if(linkRule.type !== 'id') {
                            return;
                        }

                        const matchingAncestor = element.closest('#' + linkRule.value)

                        if(!matchingAncestor || matchingAncestor.matches('html, body')) {
                            return;
                        }

                        const depth = calculateParentDistance(element, matchingAncestor)

                        if(depth < 7) {
                            ids.push(linkRule.value)
                        }
                    });

                    // For link rules that target a class, we need to allow that class to appear
                    // in any ancestor up to the 7th ancestor. This loop looks for those matches
                    // and counts them.
                    linkRules.forEach((linkRule) => {
                        if(linkRule.type !== 'class') {
                            return;
                        }

                        const matchingAncestor = element.closest('.' + linkRule.value)

                        if(!matchingAncestor || matchingAncestor.matches('html, body')) {
                            return;
                        }

                        const depth = calculateParentDistance(element, matchingAncestor)

                        if(depth < 7) {
                            classes.push(linkRule.value)
                        }
                    });

                    const hasMatch = linkRules.some((linkRule) => {
                        return isMatch(linkRule, href, classes, ids)
                    })

                    if(!hasMatch) {
                        return
                    }

                    const url = "https://hostalsolzamora.com/wp-content/plugins/independent-analytics/iawp-click-endpoint.php";
                    const body = {
                        href: href,
                        classes: classes.join(' '),
                        ids: ids.join(' '),
                        ...{"payload":{"resource":"404","not_found_url":"\/Popover%20requires%20tooltip.js","page":1},"signature":"6772f130eeaa46b13940fd0619bfa71a"}                    };

                    sendRequest(url, body)
                }
                document.addEventListener('mousedown', function (event) {
                                        if (navigator.webdriver || /bot|crawler|spider|crawling|semrushbot|chrome-lighthouse/i.test(navigator.userAgent)) {
                        return;
                    }
                    
                    const element = event.target.closest('a')

                    if(!element) {
                        return
                    }

                    const isPro = false
                    if(!isPro) {
                        return
                    }

                    // Don't track left clicks with this event. The click event is used for that.
                    if(event.button === 0) {
                        return
                    }

                    track(element)
                })
                document.addEventListener('click', function (event) {
                                        if (navigator.webdriver || /bot|crawler|spider|crawling|semrushbot|chrome-lighthouse/i.test(navigator.userAgent)) {
                        return;
                    }
                    
                    const element = event.target.closest('a, button, input[type="submit"], input[type="button"]')

                    if(!element) {
                        return
                    }

                    const isPro = false
                    if(!isPro) {
                        return
                    }

                    track(element)
                })
                document.addEventListener('play', function (event) {
                                        if (navigator.webdriver || /bot|crawler|spider|crawling|semrushbot|chrome-lighthouse/i.test(navigator.userAgent)) {
                        return;
                    }
                    
                    const element = event.target.closest('audio, video')

                    if(!element) {
                        return
                    }

                    const isPro = false
                    if(!isPro) {
                        return
                    }

                    track(element)
                }, true)
                document.addEventListener("DOMContentLoaded", function (e) {
                    if (document.hasOwnProperty("visibilityState") && document.visibilityState === "prerender") {
                        return;
                    }

                                            if (navigator.webdriver || /bot|crawler|spider|crawling|semrushbot|chrome-lighthouse/i.test(navigator.userAgent)) {
                            return;
                        }
                    
                    let referrer_url = null;

                    if (typeof document.referrer === 'string' && document.referrer.length > 0) {
                        referrer_url = document.referrer;
                    }

                    const params = location.search.slice(1).split('&').reduce((acc, s) => {
                        const [k, v] = s.split('=');
                        return Object.assign(acc, {[k]: v});
                    }, {});

                    const url = "https://hostalsolzamora.com/wp-json/iawp/search";
                    const body = {
                        referrer_url,
                        utm_source: params.utm_source,
                        utm_medium: params.utm_medium,
                        utm_campaign: params.utm_campaign,
                        utm_term: params.utm_term,
                        utm_content: params.utm_content,
                        gclid: params.gclid,
                        ...{"payload":{"resource":"404","not_found_url":"\/Popover%20requires%20tooltip.js","page":1},"signature":"6772f130eeaa46b13940fd0619bfa71a"}                    };

                    sendRequest(url, body)
                });
            })();
        </script>
        
<!-- Consent Management powered by Complianz | GDPR/CCPA Cookie Consent https://wordpress.org/plugins/complianz-gdpr -->
<div id="cmplz-cookiebanner-container"><div class="cmplz-cookiebanner cmplz-hidden banner-1 bottom-right-view-preferences optin cmplz-bottom-right cmplz-categories-type-no" aria-modal="true" data-nosnippet="true" role="dialog" aria-live="polite" aria-labelledby="cmplz-header-1-optin" aria-describedby="cmplz-message-1-optin">
	<div class="cmplz-header">
		<div class="cmplz-logo"><img width="4500" height="3180" src="https://hostalsolzamora.com/wp-content/uploads/2022/03/logotipo-cuadrado.png" class="attachment-cmplz_banner_image size-cmplz_banner_image" alt="Hostal Sol Zamora" decoding="async" loading="lazy" srcset="https://hostalsolzamora.com/wp-content/uploads/2022/03/logotipo-cuadrado.png 4500w, https://hostalsolzamora.com/wp-content/uploads/2022/03/logotipo-cuadrado-300x212.png 300w, https://hostalsolzamora.com/wp-content/uploads/2022/03/logotipo-cuadrado-1024x724.png 1024w, https://hostalsolzamora.com/wp-content/uploads/2022/03/logotipo-cuadrado-768x543.png 768w, https://hostalsolzamora.com/wp-content/uploads/2022/03/logotipo-cuadrado-1536x1085.png 1536w, https://hostalsolzamora.com/wp-content/uploads/2022/03/logotipo-cuadrado-2048x1447.png 2048w" sizes="auto, (max-width: 4500px) 100vw, 4500px" /></div>
		<div class="cmplz-title" id="cmplz-header-1-optin">Gestionar el consentimiento de las cookies</div>
		<div class="cmplz-close" tabindex="0" role="button" aria-label="Cerrar el diálogo">
			<svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="times" class="svg-inline--fa fa-times fa-w-11" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 352 512"><path fill="currentColor" d="M242.72 256l100.07-100.07c12.28-12.28 12.28-32.19 0-44.48l-22.24-22.24c-12.28-12.28-32.19-12.28-44.48 0L176 189.28 75.93 89.21c-12.28-12.28-32.19-12.28-44.48 0L9.21 111.45c-12.28 12.28-12.28 32.19 0 44.48L109.28 256 9.21 356.07c-12.28 12.28-12.28 32.19 0 44.48l22.24 22.24c12.28 12.28 32.2 12.28 44.48 0L176 322.72l100.07 100.07c12.28 12.28 32.2 12.28 44.48 0l22.24-22.24c12.28-12.28 12.28-32.19 0-44.48L242.72 256z"></path></svg>
		</div>
	</div>

	<div class="cmplz-divider cmplz-divider-header"></div>
	<div class="cmplz-body">
		<div class="cmplz-message" id="cmplz-message-1-optin">Para ofrecer las mejores experiencias, utilizamos tecnologías como las cookies para almacenar y/o acceder a la información del dispositivo. El consentimiento de estas tecnologías nos permitirá procesar datos como el comportamiento de navegación o las identificaciones únicas en este sitio. No consentir o retirar el consentimiento, puede afectar negativamente a ciertas características y funciones.</div>
		<!-- categories start -->
		<div class="cmplz-categories">
			<details class="cmplz-category cmplz-functional" >
				<summary>
						<span class="cmplz-category-header">
							<span class="cmplz-category-title">Funcional</span>
							<span class='cmplz-always-active'>
								<span class="cmplz-banner-checkbox">
									<input type="checkbox"
										   id="cmplz-functional-optin"
										   data-category="cmplz_functional"
										   class="cmplz-consent-checkbox cmplz-functional"
										   size="40"
										   value="1"/>
									<label class="cmplz-label" for="cmplz-functional-optin"><span class="screen-reader-text">Funcional</span></label>
								</span>
								Siempre activo							</span>
							<span class="cmplz-icon cmplz-open">
								<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"  height="18" ><path d="M224 416c-8.188 0-16.38-3.125-22.62-9.375l-192-192c-12.5-12.5-12.5-32.75 0-45.25s32.75-12.5 45.25 0L224 338.8l169.4-169.4c12.5-12.5 32.75-12.5 45.25 0s12.5 32.75 0 45.25l-192 192C240.4 412.9 232.2 416 224 416z"/></svg>
							</span>
						</span>
				</summary>
				<div class="cmplz-description">
					<span class="cmplz-description-functional">El almacenamiento o acceso técnico es estrictamente necesario para el propósito legítimo de permitir el uso de un servicio específico explícitamente solicitado por el abonado o usuario, o con el único propósito de llevar a cabo la transmisión de una comunicación a través de una red de comunicaciones electrónicas.</span>
				</div>
			</details>

			<details class="cmplz-category cmplz-preferences" >
				<summary>
						<span class="cmplz-category-header">
							<span class="cmplz-category-title">Preferencias</span>
							<span class="cmplz-banner-checkbox">
								<input type="checkbox"
									   id="cmplz-preferences-optin"
									   data-category="cmplz_preferences"
									   class="cmplz-consent-checkbox cmplz-preferences"
									   size="40"
									   value="1"/>
								<label class="cmplz-label" for="cmplz-preferences-optin"><span class="screen-reader-text">Preferencias</span></label>
							</span>
							<span class="cmplz-icon cmplz-open">
								<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"  height="18" ><path d="M224 416c-8.188 0-16.38-3.125-22.62-9.375l-192-192c-12.5-12.5-12.5-32.75 0-45.25s32.75-12.5 45.25 0L224 338.8l169.4-169.4c12.5-12.5 32.75-12.5 45.25 0s12.5 32.75 0 45.25l-192 192C240.4 412.9 232.2 416 224 416z"/></svg>
							</span>
						</span>
				</summary>
				<div class="cmplz-description">
					<span class="cmplz-description-preferences">El almacenamiento o acceso técnico es necesario para la finalidad legítima de almacenar preferencias no solicitadas por el abonado o usuario.</span>
				</div>
			</details>

			<details class="cmplz-category cmplz-statistics" >
				<summary>
						<span class="cmplz-category-header">
							<span class="cmplz-category-title">Estadísticas</span>
							<span class="cmplz-banner-checkbox">
								<input type="checkbox"
									   id="cmplz-statistics-optin"
									   data-category="cmplz_statistics"
									   class="cmplz-consent-checkbox cmplz-statistics"
									   size="40"
									   value="1"/>
								<label class="cmplz-label" for="cmplz-statistics-optin"><span class="screen-reader-text">Estadísticas</span></label>
							</span>
							<span class="cmplz-icon cmplz-open">
								<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"  height="18" ><path d="M224 416c-8.188 0-16.38-3.125-22.62-9.375l-192-192c-12.5-12.5-12.5-32.75 0-45.25s32.75-12.5 45.25 0L224 338.8l169.4-169.4c12.5-12.5 32.75-12.5 45.25 0s12.5 32.75 0 45.25l-192 192C240.4 412.9 232.2 416 224 416z"/></svg>
							</span>
						</span>
				</summary>
				<div class="cmplz-description">
					<span class="cmplz-description-statistics">El almacenamiento o acceso técnico que es utilizado exclusivamente con fines estadísticos.</span>
					<span class="cmplz-description-statistics-anonymous">El almacenamiento o acceso técnico que se utiliza exclusivamente con fines estadísticos anónimos. Sin un requerimiento, el cumplimiento voluntario por parte de tu Proveedor de servicios de Internet, o los registros adicionales de un tercero, la información almacenada o recuperada sólo para este propósito no se puede utilizar para identificarte.</span>
				</div>
			</details>
			<details class="cmplz-category cmplz-marketing" >
				<summary>
						<span class="cmplz-category-header">
							<span class="cmplz-category-title">Marketing</span>
							<span class="cmplz-banner-checkbox">
								<input type="checkbox"
									   id="cmplz-marketing-optin"
									   data-category="cmplz_marketing"
									   class="cmplz-consent-checkbox cmplz-marketing"
									   size="40"
									   value="1"/>
								<label class="cmplz-label" for="cmplz-marketing-optin"><span class="screen-reader-text">Marketing</span></label>
							</span>
							<span class="cmplz-icon cmplz-open">
								<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"  height="18" ><path d="M224 416c-8.188 0-16.38-3.125-22.62-9.375l-192-192c-12.5-12.5-12.5-32.75 0-45.25s32.75-12.5 45.25 0L224 338.8l169.4-169.4c12.5-12.5 32.75-12.5 45.25 0s12.5 32.75 0 45.25l-192 192C240.4 412.9 232.2 416 224 416z"/></svg>
							</span>
						</span>
				</summary>
				<div class="cmplz-description">
					<span class="cmplz-description-marketing">El almacenamiento o acceso técnico es necesario para crear perfiles de usuario para enviar publicidad, o para rastrear al usuario en una web o en varias web con fines de marketing similares.</span>
				</div>
			</details>
		</div><!-- categories end -->
			</div>

	<div class="cmplz-links cmplz-information">
		<ul>
			<li><a class="cmplz-link cmplz-manage-options cookie-statement" href="#" data-relative_url="#cmplz-manage-consent-container">Administrar opciones</a></li>
			<li><a class="cmplz-link cmplz-manage-third-parties cookie-statement" href="#" data-relative_url="#cmplz-cookies-overview">Gestionar los servicios</a></li>
			<li><a class="cmplz-link cmplz-manage-vendors tcf cookie-statement" href="#" data-relative_url="#cmplz-tcf-wrapper">Manage {vendor_count} vendors</a></li>
			<li><a class="cmplz-link cmplz-external cmplz-read-more-purposes tcf" target="_blank" rel="noopener noreferrer nofollow" href="https://cookiedatabase.org/tcf/purposes/" aria-label="Read more about TCF purposes on Cookie Database">Leer más sobre estos propósitos</a></li>
		</ul>
			</div>

	<div class="cmplz-divider cmplz-footer"></div>

	<div class="cmplz-buttons">
		<button class="cmplz-btn cmplz-accept">Aceptar</button>
		<button class="cmplz-btn cmplz-deny">Denegar</button>
		<button class="cmplz-btn cmplz-view-preferences">Ver preferencias</button>
		<button class="cmplz-btn cmplz-save-preferences">Guardar preferencias</button>
		<a class="cmplz-btn cmplz-manage-options tcf cookie-statement" href="#" data-relative_url="#cmplz-manage-consent-container">Ver preferencias</a>
			</div>

	
	<div class="cmplz-documents cmplz-links">
		<ul>
			<li><a class="cmplz-link cookie-statement" href="#" data-relative_url="">{title}</a></li>
			<li><a class="cmplz-link privacy-statement" href="#" data-relative_url="">{title}</a></li>
			<li><a class="cmplz-link impressum" href="#" data-relative_url="">{title}</a></li>
		</ul>
			</div>
</div>
</div>
					<div id="cmplz-manage-consent" data-nosnippet="true"><button class="cmplz-btn cmplz-hidden cmplz-manage-consent manage-consent-1">Gestionar consentimiento</button>

</div>
	
		<div class="sh-back-to-top sh-back-to-top1">
			<i class="icon-arrow-up"></i>
		</div>

	
<script src="https://hostalsolzamora.com/wp-content/cache/minify/501dc.js"></script>

<script type="text/javascript" id="wp-i18n-js-after">
/* <![CDATA[ */
wp.i18n.setLocaleData( { 'text direction\u0004ltr': [ 'ltr' ] } );
//# sourceURL=wp-i18n-js-after
/* ]]> */
</script>
<script src="https://hostalsolzamora.com/wp-content/cache/minify/1f540.js"></script>

<script type="text/javascript" id="contact-form-7-js-before">
/* <![CDATA[ */
var wpcf7 = {
    "api": {
        "root": "https:\/\/hostalsolzamora.com\/wp-json\/",
        "namespace": "contact-form-7\/v1"
    },
    "cached": 1
};
//# sourceURL=contact-form-7-js-before
/* ]]> */
</script>



<script src="https://hostalsolzamora.com/wp-content/cache/minify/9f6b1.js"></script>

<script type="text/javascript" id="cmplz-cookiebanner-js-extra">
/* <![CDATA[ */
var complianz = {"prefix":"cmplz_","user_banner_id":"1","set_cookies":[],"block_ajax_content":"","banner_version":"22","version":"7.4.4.2","store_consent":"","do_not_track_enabled":"","consenttype":"optin","region":"eu","geoip":"","dismiss_timeout":"","disable_cookiebanner":"","soft_cookiewall":"","dismiss_on_scroll":"","cookie_expiry":"365","url":"https://hostalsolzamora.com/wp-json/complianz/v1/","locale":"lang=es&locale=es_ES","set_cookies_on_root":"","cookie_domain":"","current_policy_id":"14","cookie_path":"/","categories":{"statistics":"estad\u00edsticas","marketing":"m\u00e1rketing"},"tcf_active":"","placeholdertext":"\u003Cdiv class=\"cmplz-blocked-content-notice-body\"\u003EHaz clic en \u00abEstoy de acuerdo\u00bb para activar {service}\u00a0\u003Cdiv class=\"cmplz-links\"\u003E\u003Ca href=\"#\" class=\"cmplz-link cookie-statement\"\u003E{title}\u003C/a\u003E\u003C/div\u003E\u003C/div\u003E\u003Cbutton class=\"cmplz-accept-service\"\u003EEstoy de acuerdo\u003C/button\u003E","css_file":"https://hostalsolzamora.com/wp-content/uploads/complianz/css/banner-{banner_id}-{type}.css?v=22","page_links":{"eu":{"cookie-statement":{"title":"Pol\u00edtica de cookies ","url":"https://hostalsolzamora.com/politica-de-cookies-ue"},"privacy-statement":{"title":"Aviso Legal","url":"https://hostalsolzamora.com/aviso-legal"},"impressum":{"title":"Aviso Legal","url":"https://hostalsolzamora.com/aviso-legal"}},"us":{"impressum":{"title":"Aviso Legal","url":"https://hostalsolzamora.com/aviso-legal"}},"uk":{"impressum":{"title":"Aviso Legal","url":"https://hostalsolzamora.com/aviso-legal"}},"ca":{"impressum":{"title":"Aviso Legal","url":"https://hostalsolzamora.com/aviso-legal"}},"au":{"impressum":{"title":"Aviso Legal","url":"https://hostalsolzamora.com/aviso-legal"}},"za":{"impressum":{"title":"Aviso Legal","url":"https://hostalsolzamora.com/aviso-legal"}},"br":{"impressum":{"title":"Aviso Legal","url":"https://hostalsolzamora.com/aviso-legal"}}},"tm_categories":"","forceEnableStats":"","preview":"","clean_cookies":"1","aria_label":"Haz clic en el bot\u00f3n para activar {service}"};
//# sourceURL=cmplz-cookiebanner-js-extra
/* ]]> */
</script>
<script src="https://hostalsolzamora.com/wp-content/cache/minify/4407c.js" defer></script>

<script id="wp-emoji-settings" type="application/json">
{"baseUrl":"https://s.w.org/images/core/emoji/17.0.2/72x72/","ext":".png","svgUrl":"https://s.w.org/images/core/emoji/17.0.2/svg/","svgExt":".svg","source":{"concatemoji":"https://hostalsolzamora.com/wp-includes/js/wp-emoji-release.min.js?ver=6.9.4"}}
</script>
<script type="module">
/* <![CDATA[ */
/*! This file is auto-generated */
const a=JSON.parse(document.getElementById("wp-emoji-settings").textContent),o=(window._wpemojiSettings=a,"wpEmojiSettingsSupports"),s=["flag","emoji"];function i(e){try{var t={supportTests:e,timestamp:(new Date).valueOf()};sessionStorage.setItem(o,JSON.stringify(t))}catch(e){}}function c(e,t,n){e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(t,0,0);t=new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data);e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(n,0,0);const a=new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data);return t.every((e,t)=>e===a[t])}function p(e,t){e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(t,0,0);var n=e.getImageData(16,16,1,1);for(let e=0;e<n.data.length;e++)if(0!==n.data[e])return!1;return!0}function u(e,t,n,a){switch(t){case"flag":return n(e,"\ud83c\udff3\ufe0f\u200d\u26a7\ufe0f","\ud83c\udff3\ufe0f\u200b\u26a7\ufe0f")?!1:!n(e,"\ud83c\udde8\ud83c\uddf6","\ud83c\udde8\u200b\ud83c\uddf6")&&!n(e,"\ud83c\udff4\udb40\udc67\udb40\udc62\udb40\udc65\udb40\udc6e\udb40\udc67\udb40\udc7f","\ud83c\udff4\u200b\udb40\udc67\u200b\udb40\udc62\u200b\udb40\udc65\u200b\udb40\udc6e\u200b\udb40\udc67\u200b\udb40\udc7f");case"emoji":return!a(e,"\ud83e\u1fac8")}return!1}function f(e,t,n,a){let r;const o=(r="undefined"!=typeof WorkerGlobalScope&&self instanceof WorkerGlobalScope?new OffscreenCanvas(300,150):document.createElement("canvas")).getContext("2d",{willReadFrequently:!0}),s=(o.textBaseline="top",o.font="600 32px Arial",{});return e.forEach(e=>{s[e]=t(o,e,n,a)}),s}function r(e){var t=document.createElement("script");t.src=e,t.defer=!0,document.head.appendChild(t)}a.supports={everything:!0,everythingExceptFlag:!0},new Promise(t=>{let n=function(){try{var e=JSON.parse(sessionStorage.getItem(o));if("object"==typeof e&&"number"==typeof e.timestamp&&(new Date).valueOf()<e.timestamp+604800&&"object"==typeof e.supportTests)return e.supportTests}catch(e){}return null}();if(!n){if("undefined"!=typeof Worker&&"undefined"!=typeof OffscreenCanvas&&"undefined"!=typeof URL&&URL.createObjectURL&&"undefined"!=typeof Blob)try{var e="postMessage("+f.toString()+"("+[JSON.stringify(s),u.toString(),c.toString(),p.toString()].join(",")+"));",a=new Blob([e],{type:"text/javascript"});const r=new Worker(URL.createObjectURL(a),{name:"wpTestEmojiSupports"});return void(r.onmessage=e=>{i(n=e.data),r.terminate(),t(n)})}catch(e){}i(n=f(s,u,c,p))}t(n)}).then(e=>{for(const n in e)a.supports[n]=e[n],a.supports.everything=a.supports.everything&&a.supports[n],"flag"!==n&&(a.supports.everythingExceptFlag=a.supports.everythingExceptFlag&&a.supports[n]);var t;a.supports.everythingExceptFlag=a.supports.everythingExceptFlag&&!a.supports.flag,a.supports.everything||((t=a.source||{}).concatemoji?r(t.concatemoji):t.wpemoji&&t.twemoji&&(r(t.twemoji),r(t.wpemoji)))});
//# sourceURL=https://hostalsolzamora.com/wp-includes/js/wp-emoji-loader.min.js
/* ]]> */
</script>
		<script type="text/javascript"> jQuery(document).ready(function ($) { "use strict"; jQuery(document).ready( function($){}); });</script>
	
<script src="https://widget.siteminder.com/ibe.min.js"></script>
</body>
</html>

<!--
Performance optimized by W3 Total Cache. Learn more: https://www.boldgrid.com/w3-total-cache/?utm_source=w3tc&utm_medium=footer_comment&utm_campaign=free_plugin

Almacenamiento en caché de páginas con Disk: Enhanced (Page is 404) 
Minified using Disk

Served from: hostalsolzamora.com @ 2026-05-13 22:40:04 by W3 Total Cache
-->